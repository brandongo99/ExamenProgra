/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package brandon;
import java.util.Scanner;
/**
 *
 * @author estudiante
 */
public class Brandon {
   
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
         double A; 
         double B;
         
         System.out.println("Ingrese la Cantidad 1");
         Scanner A1 = new Scanner (System.in);
         A = A1.nextDouble ();
         
         System.out.println("Ingrese la Cantidad 2");
         Scanner B1 = new Scanner (System.in);
         B = B1.nextDouble ();
         
         double C = A+B;
         
         System.out.println("La sumatoria de las dos cantidades es: " + C);
    
    }
    
}
